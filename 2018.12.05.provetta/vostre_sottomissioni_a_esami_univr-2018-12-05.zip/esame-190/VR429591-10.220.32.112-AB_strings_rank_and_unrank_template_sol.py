#!/usr/bin/env python3
# -*- coding: latin-1 -*-

# Template di soluzione per il problema rank_unrank_ABstrings

def ABstring2rank(s):
    posizione= 0
    length_list_ord= 2**(len(s))
    for i in range(len(input_string)):
        if input_string[i]=='A':
            posizione=posizione
        elif input_string[i]=='B':
            posizione= length_list_ord-1
         
        
        
        return posizione

def ABstring_of_len_and_rank(length, r):
    return "ABBA"        




input_string = input()

if input_string[0] == 'A' or input_string[0] == 'B':
   print( ABstring2rank(input_string) )
else:
   length, r = input_string.split()
   print( ABstring_of_len_and_rank(int(length), int(r)) )

