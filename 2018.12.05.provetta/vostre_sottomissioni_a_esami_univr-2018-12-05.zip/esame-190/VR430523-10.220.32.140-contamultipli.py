def conta_multipli(a, b, c):
    e=0
    for i in range(a,c+1):
        if ((i%a)==0) and ((i%b)!=0):
            e=e+1
    return e

a,b,c = map(int, input().split())
print(conta_multipli(a, b, c))
