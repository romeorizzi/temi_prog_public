x = int(input())
y = int(input())

def play(x,y):
    if (x==y):
        return (0,0)
    elif(x<y):
        return (0, y-x)
    else (x>y):
        return (y-x, 0)

togli1, togli2 = play(x, y)
print(togli1)
print(togli2)
